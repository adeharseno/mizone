<div class="row">
<div class="hidden">
	<input type="text" name="href_orderby" value="<?php echo $class_name ?>/order">
</div>
	<div class="col-md-8">
		<div class="box-desc">
			<div class="item">
				<div class="desc-table"><span class="count"><?php echo count($messages) ?></span> Message<span class="s"><?php //echo count($table) == 1 ? "" : "" ?></span></div>
			</div>
		</div>
	</div>
	<div class="col-md-12 mt20">
		<table class="table responsive-data-table table-hover js-table" reorder="true">
			<thead>
				<tr>
					<td class="text-center">#</td>
					<td>Message</td>
					
				</tr>
			</thead>
			<tbody>
			<?php $i = 1 ?>
			
			<?php foreach ($messages as $key => $value): ?>
				<tr class="js-click-checkbox">
					<td class="reorder"><?php echo $i ?></td>
					<td>
						<p>From: <?php echo $value->email; ?> (<?php echo $value->name; ?>)</p>
						<p>Bussiness / Company: <?php echo $value->company_name; ?></p>
						<p>Phone: <?php echo $value->phone_number; ?></p>
						<p>Receive: <?php echo date_format(date_create($value->created_at),"D, M j, Y g:i A"); ?></p><br><br>
						<p>Topic: <?php echo $value->topic; ?></p>
						<p>Subject: <?php echo $value->subject; ?></p>
						<p><div style="width:750px;">" <?php echo $value->message; ?> "</div></p><br><br>
						<p>Prefereable contact by: <?php if($value->contact_to==0){ echo "Email"; }else if($value->contact_to==1){ echo "Phone"; }else if($value->contact_to==2){ echo "Email and Phone"; } ?></p>
                    </td>
				</tr>
				<?php $i++ ?>
			<?php endforeach ?>	
			</tbody>
		</table>
	</div>
</div>
